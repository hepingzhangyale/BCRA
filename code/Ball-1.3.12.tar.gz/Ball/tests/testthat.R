library(testthat)
library(Ball)

test_check("Ball")
